<?php

namespace App\Services;

class NexmoService{

	public __construct(){

	}

	public function getVerficationCode($phone){

		
	}
}
