<!DOCTYPE html>
<html>
<head>
    <title>Feedback from user</title>
</head>
<body>

<h1><?php echo e($details['subject']); ?></h1>
<p><?php echo e($details['message']); ?></p>

<p style="margin-top: 20px;">Wependio</p>
</body>
</html>
<?php /**PATH /Users/ameerhamza/Documents/maahey/nstant/nstant/resources/views/mails/feedback_mail.blade.php ENDPATH**/ ?>