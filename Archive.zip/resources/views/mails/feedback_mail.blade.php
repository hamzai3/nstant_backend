<!DOCTYPE html>
<html>
<head>
    <title>Feedback from user</title>
</head>
<body>

<h1>{{ $details['subject'] }}</h1>
<p>{{ $details['message'] }}</p>

<p style="margin-top: 20px;">Nstant</p>
</body>
</html>
